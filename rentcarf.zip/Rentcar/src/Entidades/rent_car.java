/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author ndada
 */
public class rent_car {
    /*atributos que representan los datos de un usuario en la base de datos*/
    private int rentcar;
    private int tipos_de_autos;
    private int reserva;
    private int asociarse;   
    private int reseña;
    private boolean Activo;     
    private String observacion;
    /*constructor para inicializar los atributps*/

    public rent_car(int rentcar, int tipos_de_autos, int reserva, int asociarse, int reseña, boolean Activo,String observacion) {
        this.rentcar = rentcar;
        this.tipos_de_autos = tipos_de_autos;
        this.reserva = reserva;
        this.asociarse = asociarse;
        this.reseña = reseña;
        this.Activo = Activo;
        this.observacion = observacion;
    }
/*metodos getter para obtener los valores de los atributos*/

    public rent_car() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getRentcar() {
        return rentcar;
    }

    public void setRentcar(int rentcar) {
        this.rentcar = rentcar;
    }

    public int getTipos_de_autos() {
        return tipos_de_autos;
    }

    public void setTipos_de_autos(int tipos_de_autos) {
        this.tipos_de_autos = tipos_de_autos;
    }

    public int getReserva() {
        return reserva;
    }

    public void setReserva(int reserva) {
        this.reserva = reserva;
    }

    public int getAsociarse() {
        return asociarse;
    }

    public void setAsociarse(int asociarse) {
        this.asociarse = asociarse;
    }

    public int getReseña() {
        return reseña;
    }

    public void setReseña(int reseña) {
        this.reseña = reseña;
    }

    public boolean isActivo() {
        return Activo;
    }

    public void setActivo(boolean Activo) {
        this.Activo = Activo;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }
    
/*metodo tostring para representar el objeto como una cadena de texto*/

    @Override
    public String toString() {
        return "rent_car{" + "rentcar=" + rentcar + ", tipos_de_autos=" + tipos_de_autos + ", reserva=" + reserva + ", asociarse=" + asociarse + ", rese\u00f1a=" + reseña + ", Activo=" + Activo + ", observacion=" + observacion + '}';
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String gettipos_de_autos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getasociarse() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void settipos_de_autos(String nombre) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setasociarse(String descripcion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setId(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getreserva() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getreseña() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
